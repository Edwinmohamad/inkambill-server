require('dotenv').config();
process.env.TZ = process.env.TZ || 'Asia/Jakarta';

const express = require('express');
const path = require('path');
const fs = require('fs');
const session = require('express-session');
const MySQLStoreFactory = require('express-mysql-session');
const expressLayouts = require('express-ejs-layouts');
const bcrypt = require('bcryptjs');
const cron = require('node-cron');
const db = require('./config/db');
const csrf = require('./middleware/csrf');
const commonLocals = require('./middleware/common');
const paymentProofUpload = require('./middleware/paymentProofUpload');
const customerExcelUpload = require('./middleware/customerExcelUpload');
const clusterExcelUpload = require('./middleware/clusterExcelUpload');
const invoiceExcelUpload = require('./middleware/invoiceExcelUpload');
const profilePhotoUpload = require('./middleware/profilePhotoUpload');
const cashProofUpload = require('./middleware/cashProofUpload');
const debtProofUpload = require('./middleware/debtProofUpload');
const ticketPhotoUpload = require('./middleware/ticketPhotoUpload');
const dutyProofUpload = require('./middleware/dutyProofUpload');
const invoiceLogoUpload = require('./middleware/invoiceLogoUpload');
const { requireAuth, loadPermissions, requirePermission, requireAnyPermission, requireMasterAdmin } = require('./middleware/auth');
const { generateMonthlyInvoices } = require('./services/invoiceService');
const { runAutoIsolation } = require('./services/networkService');
const { captureAllNmsTelemetry, backupAllRouters } = require('./services/nmsTelemetryService');
const { evaluateNetworkIncidents } = require('./services/networkAlertService');
const { pingAllOlts } = require('./services/oltService');
const { syncDevices: syncAcsDevices } = require('./services/acsService');
const { scanLowStock } = require('./services/inventoryService');
const { deliverMobilePushes } = require('./services/mobilePushService');
const { runCashAgingAlert } = require('./services/cashSettlementService');
const { purgeOldLogs } = require('./services/logRetentionService');
const { ensureV56Schema } = require('./services/waCrmSchema');
const { ensureNmsV2Schema, purgeNmsHistory } = require('./services/nms/schema');
const nmsPoller = require('./services/nms/poller');
const { refreshBroadcastStatuses } = require('./services/waBroadcastService');
const waRealtime = require('./services/waRealtime');
const { ensureV14Schema, ensureV15Schema, ensureV16Schema, ensureV17Schema, ensureV18Schema, ensureV19Schema, ensureV20Schema, ensureV21Schema, ensureV22Schema, ensureV23Schema, ensureV24Schema, ensureV25Schema, ensureV26Schema, ensureV27Schema, ensureV29Schema, ensureV30Schema, ensureV31Schema, ensureV32Schema, ensureV33Schema, ensureV34Schema, ensureV35Schema, ensureV36Schema, ensureV37Schema, ensureV38Schema, ensureV39Schema, ensureV40Schema, ensureV41Schema, ensureV42Schema, ensureV43Schema, ensureV44Schema, ensureV45Schema, ensureV46Schema, ensureV47Schema, ensureV48Schema, ensureV49Schema, ensureV50Schema, ensureV51Schema, ensureV52Schema, ensureV53Schema, ensureV54Schema, ensureV55Schema } = require('./services/schemaService');
const { requireN8nToken } = require('./middleware/n8n');
const { initGatewayOnBoot, ensureGatewayAlive, reconcileGatewayStatus, processQueue, runAutoReminderSweep } = require('./services/whatsappGatewayService');
const { requireWahaWebhookToken } = require('./middleware/waha');

const app = express();
const assetVersion = ['public/css/app.css','public/css/mobile-app.css','public/css/monitoring.css','public/js/app.js','public/js/mobile-app.js','public/js/nms-common.js','public/js/nms-noc.js','public/js/nms-secrets.js','public/js/nms-insights.js','public/js/nms-automation.js','public/css/nms-noc.css','public/js/performance.js','public/js/monitoring.js']
  .map(file => Math.floor(fs.statSync(path.join(__dirname,file)).mtimeMs).toString(36))
  .join('-');
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(expressLayouts);
app.set('layout', 'partials/layout');
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'),{maxAge:process.env.NODE_ENV==='production'?'7d':0,immutable:process.env.NODE_ENV==='production',etag:true,lastModified:true}));
app.set('trust proxy', 1);
app.use((req,res,next)=>{res.locals.assetVersion=assetVersion;next();});

// Baseline security headers for an internal admin application behind Cloudflare.
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

const MySQLStore = MySQLStoreFactory(session);
const sessionStore = new MySQLStore({
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'inkamnet',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'inkamnet',
  createDatabaseTable: true
});

// Disimpan ke variabel agar bisa dipakai ulang untuk autentikasi WebSocket Web Inbox (waRealtime).
const sessionMiddleware = session({
  name: 'inkamnet.sid',
  secret: process.env.SESSION_SECRET || 'change-this-secret-now',
  store: sessionStore,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.COOKIE_SECURE === 'true', maxAge: 1000*60*60*12 }
});
app.use(sessionMiddleware);
app.use(loadPermissions);
app.use(commonLocals);
// Parse multipart payment-proof forms before CSRF validation so the hidden token is available.
app.use('/customers/import', (req, res, next) => {
  if (req.method === 'POST' && req.is('multipart/form-data')) {
    return customerExcelUpload(req, res, (err) => {
      if (err) {
        req.session.flash = { type: 'danger', message: err.code === 'LIMIT_FILE_SIZE' ? 'File Excel maksimal 8 MB.' : err.message };
        return res.redirect('/customers');
      }
      next();
    });
  }
  next();
});
app.use('/clusters/import', (req, res, next) => {
  if (req.method === 'POST' && req.is('multipart/form-data')) {
    return clusterExcelUpload(req, res, (err) => {
      if (err) {
        req.session.flash = { type: 'danger', message: err.code === 'LIMIT_FILE_SIZE' ? 'File Excel maksimal 8 MB.' : err.message };
        return res.redirect('/clusters');
      }
      next();
    });
  }
  next();
});
app.use('/invoices/import', (req, res, next) => {
  if (req.method === 'POST' && req.is('multipart/form-data')) {
    return invoiceExcelUpload(req, res, (err) => {
      if (err) {
        req.session.flash = { type: 'danger', message: err.code === 'LIMIT_FILE_SIZE' ? 'File Excel maksimal 8 MB.' : err.message };
        return res.redirect('/invoices');
      }
      next();
    });
  }
  next();
});
app.use('/profile', (req, res, next) => {
  if (req.method === 'POST' && req.path === '/' && req.is('multipart/form-data')) {
    return profilePhotoUpload(req, res, (err) => {
      if (err) {
        req.session.flash = { type: 'danger', message: err.code === 'LIMIT_FILE_SIZE' ? 'Foto profil maksimal 4 MB.' : err.message };
        return res.redirect('/profile');
      }
      next();
    });
  }
  next();
});
app.use('/payments', (req, res, next) => {
  if (['POST','PUT','PATCH'].includes(req.method) && req.is('multipart/form-data')) {
    return paymentProofUpload(req, res, (err) => {
      if (err) {
        req.session.flash = { type: 'danger', message: err.code === 'LIMIT_FILE_SIZE' ? 'Bukti pembayaran maksimal 6 MB.' : err.message };
        return res.redirect('/payments');
      }
      next();
    });
  }
  next();
});
app.use('/cash', (req, res, next) => {
  if (['POST','PUT','PATCH'].includes(req.method) && req.is('multipart/form-data')) {
    return cashProofUpload(req, res, (err) => {
      if (err) {
        req.session.flash = { type: 'danger', message: err.code === 'LIMIT_FILE_SIZE' ? 'Bukti pengeluaran maksimal 6 MB.' : err.message };
        return res.redirect('/cash');
      }
      next();
    });
  }
  next();
});
app.use('/debts', (req, res, next) => {
  if (['POST','PUT','PATCH'].includes(req.method) && req.is('multipart/form-data')) {
    return debtProofUpload(req, res, (err) => {
      if (err) {
        req.session.flash = { type: 'danger', message: err.code === 'LIMIT_FILE_SIZE' ? 'Lampiran bukti cicilan maksimal 6 MB.' : err.message };
        return res.redirect('/debts');
      }
      next();
    });
  }
  next();
});
app.use('/tickets', (req, res, next) => {
  if (['POST','PUT','PATCH'].includes(req.method) && req.is('multipart/form-data')) {
    return ticketPhotoUpload(req, res, (err) => {
      if (err) {
        req.session.flash = { type: 'danger', message: err.code === 'LIMIT_FILE_SIZE' ? 'Lampiran ticket maksimal 6 MB.' : err.message };
        const match=req.path.match(/^\/(\d+)/);
        return res.redirect(match?`/tickets/${match[1]}`:'/tickets');
      }
      next();
    });
  }
  next();
});
app.use('/server-duty', (req, res, next) => {
  if (['POST','PUT','PATCH'].includes(req.method) && req.is('multipart/form-data')) {
    return dutyProofUpload(req, res, (err) => {
      if (err) {
        req.session.flash = { type: 'danger', message: err.code === 'LIMIT_FILE_SIZE' ? 'Bukti piket maksimal 6 MB.' : err.message };
        return res.redirect('/server-duty');
      }
      next();
    });
  }
  next();
});
app.use('/settings/invoice-branding', requireAuth, (req, res, next) => {
  if (!(req.permissions || []).includes('settings')) return res.status(403).send('Akses pengaturan dibatasi.');
  next();
}, (req, res, next) => {
  if (req.method === 'POST' && req.is('multipart/form-data')) {
    return invoiceLogoUpload(req, res, (err) => {
      if (err) {
        req.session.flash = { type: 'danger', message: err.code === 'LIMIT_FILE_SIZE' ? 'Logo invoice maksimal 3 MB.' : err.message };
        return res.redirect('/settings?tab=invoice');
      }
      next();
    });
  }
  next();
});
app.use(csrf);
app.use(require('./routes/mobile'));

// Token-protected server-to-server entrypoint for the versioned n8n workflows.
// It is intentionally mounted after the JSON parser and before browser routes.
app.use('/api/n8n', requireN8nToken, require('./routes/n8n'));

// Token-protected inbound webhook FROM WAHA (WhatsApp HTTP API) — pushes session status /
// message events into the WA Gateway module. See services/whatsappGatewayService.js.
app.use('/api/waha', requireWahaWebhookToken, require('./routes/waha'));

// Lightweight health endpoint used by Docker/operations monitoring.
app.get('/healthz', async (req, res) => {
  try {
    await db.query('SELECT 1');
    res.status(200).json({ status: 'ok', service: 'inkamnet-control-center' });
  } catch (err) {
    res.status(503).json({ status: 'error' });
  }
});

app.use(require('./routes/auth'));
// v1.28 — "Cash Saya" untuk setiap user yang login (hanya data miliknya sendiri).
app.use('/my-cash', requireAuth, require('./routes/myCash'));
app.use('/', requireAuth, requirePermission('dashboard'), require('./routes/dashboard'));
app.use('/analytics', requireAuth, requirePermission('finance'), require('./routes/analytics'));
app.use('/customers', requireAuth, requirePermission('customers'), require('./routes/customers'));
app.use('/packages', requireAuth, requirePermission('customers'), require('./routes/packages'));
app.use('/invoices', requireAuth, requirePermission('billing'), require('./routes/invoices'));
app.use('/payments', requireAuth, requireAnyPermission('billing', 'finance'), require('./routes/payments'));
app.use('/reports', requireAuth, requirePermission('reports'), require('./routes/reports'));
app.use('/debts', requireAuth, requirePermission('finance'), require('./routes/debts'));
app.use('/closing', requireAuth, requireMasterAdmin, require('./routes/closing'));
app.use('/routers', requireAuth, requirePermission('network'), require('./routes/routers'));
app.use('/network', requireAuth, requirePermission('network'), require('./routes/network'));
app.use('/nms', requireAuth, requirePermission('network'), require('./routes/nms'));
app.use('/acs', requireAuth, requirePermission('network'), require('./routes/acs'));
app.use('/olt', requireAuth, requirePermission('network'), require('./routes/olt'));
app.use('/monitoring', requireAuth, requirePermission('network'), require('./routes/monitoring'));
app.use('/settings', requireAuth, requirePermission('settings'), require('./routes/settings'));
app.use('/profile', requireAuth, require('./routes/profile'));
app.use('/communication', requireAuth, require('./routes/communication'));
app.use('/clusters', requireAuth, requirePermission('network'), require('./routes/clusters'));
app.use('/tickets', requireAuth, requirePermission('support'), require('./routes/tickets'));
app.use('/team-kpi', requireAuth, requirePermission('support'), require('./routes/teamKpi'));
app.use('/schedules', requireAuth, requirePermission('support'), require('./routes/schedules'));
app.use('/server-duty', requireAuth, requirePermission('support'), require('./routes/serverDuty'));
app.use('/inventory', requireAuth, requirePermission('warehouse'), require('./routes/inventory'));
app.use('/sites', requireAuth, requirePermission('network'), require('./routes/sites'));
app.use('/custom-invoices', requireAuth, requirePermission('billing'), require('./routes/customInvoices'));
app.use('/logs', requireAuth, requirePermission('logs'), require('./routes/logs'));
app.use('/', requireAuth, require('./routes/finance'));
app.use('/wa-inbox', requireAuth, require('./routes/waInbox'));
app.use('/wa-gateway', requireAuth, require('./routes/waCrm'));
app.use('/wa-gateway', requireAuth, require('./routes/whatsappGateway'));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).send(`Terjadi error: ${process.env.NODE_ENV === 'production' ? 'cek log server' : err.message}`);
});

async function bootstrap() {
  if (process.env.NODE_ENV === 'production') {
    const secret = String(process.env.SESSION_SECRET || '');
    const routerKey = String(process.env.ROUTER_CREDENTIAL_KEY || '');
    const adminPassword = String(process.env.DEFAULT_ADMIN_PASSWORD || '');
    if (secret.length < 32 || secret.includes('GANTI_') || secret === 'change-this-secret-now') throw new Error('SESSION_SECRET wajib random minimal 32 karakter.');
    if (routerKey.length < 32 || routerKey.includes('GANTI_')) throw new Error('ROUTER_CREDENTIAL_KEY wajib random minimal 32 karakter.');
    if (!process.env.DB_PASSWORD || String(process.env.DB_PASSWORD).includes('GANTI_')) throw new Error('DB_PASSWORD belum dikonfigurasi.');
    if (!process.env.DB_ROOT_PASSWORD || String(process.env.DB_ROOT_PASSWORD).includes('GANTI_')) throw new Error('DB_ROOT_PASSWORD belum dikonfigurasi.');
    if (!adminPassword || adminPassword.includes('GantiPassword')) throw new Error('DEFAULT_ADMIN_PASSWORD wajib diganti sebelum startup production.');
  }
  await db.query('SELECT 1');
  await ensureV14Schema();
  await ensureV15Schema();
  await ensureV16Schema();
  await ensureV17Schema();
  await ensureV18Schema();
  await ensureV19Schema();
  await ensureV20Schema();
  await ensureV21Schema();
  await ensureV22Schema();
  await ensureV23Schema();
  await ensureV24Schema();
  await ensureV25Schema();
  await ensureV26Schema();
  await ensureV27Schema();
  await ensureV29Schema();
  await ensureV30Schema();
  await ensureV31Schema();
  await ensureV32Schema();
  await ensureV33Schema();
  await ensureV34Schema();
  await ensureV35Schema();
  await ensureV36Schema();
  await ensureV37Schema();
  await ensureV38Schema();
  await ensureV39Schema();
  await ensureV40Schema();
  await ensureV41Schema();
  await ensureV42Schema();
  await ensureV43Schema();
  await ensureV44Schema();
  await ensureV45Schema();
  await ensureV46Schema();
  await ensureV47Schema();
  await ensureV48Schema();
  await ensureV49Schema();
  await ensureV50Schema();
  await ensureV51Schema();
  await ensureV52Schema();
  await ensureV53Schema();
  await ensureV54Schema();
  await ensureV55Schema();
  await ensureV56Schema();
  await ensureNmsV2Schema();
  const [rows] = await db.query('SELECT COUNT(*) total FROM users');
  if (Number(rows[0].total) === 0) {
    const username = process.env.DEFAULT_ADMIN_USERNAME || 'admin';
    const password = process.env.DEFAULT_ADMIN_PASSWORD || 'Admin123!';
    const name = process.env.DEFAULT_ADMIN_NAME || 'Administrator';
    const hash = await bcrypt.hash(password, 12);
    await db.execute(`INSERT INTO users (name,username,password_hash,role,is_active) VALUES (?,?,?,'admin',1)`, [name, username, hash]);
    console.log(`Admin awal dibuat: ${username}`);
  }

  cron.schedule('10 0 * * *', async () => {
    try {
      console.log('Cron invoice:', await generateMonthlyInvoices(new Date(), false, null));
      // Isolir otomatis kini dijalankan oleh NMS automation di jam yang diatur (Otomasi → Isolir harian,
      // default jam 00 = perilaku lama). Lihat cron nmsAutomation di bawah.
    } catch (err) { console.error('Cron billing/network gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });

  cron.schedule('30 2 * * 0', async () => {
    try { console.log('Cron retensi log:',await purgeOldLogs(7)); }
    catch (err) { console.error('Cron retensi log gagal:',err.message); }
  }, { timezone: 'Asia/Jakarta' });

  // WA Gateway watchdog — every 5 minutes: (1) resume the send queue in case it stalled while the
  // gateway was briefly disconnected, and (2) check whether it's time to run the once-daily
  // auto-reminder sweep (runAutoReminderSweep itself no-ops unless enabled, past the configured hour,
  // and not already run today, so this can safely fire every 5 minutes without double-sending).
  cron.schedule('*/5 * * * *', async () => {
    // Safety-net resync with WAHA in case a webhook push was ever missed (WAHA restart, network
    // blip, etc.) — the webhook (routes/waha.js) is the fast path, this just keeps things honest.
    try { await reconcileGatewayStatus(); } catch (err) { console.error('WA Gateway status reconcile gagal:', err.message); }
    try { await processQueue(); } catch (err) { console.error('WA Gateway queue watchdog gagal:', err.message); }
    try {
      const result = await runAutoReminderSweep();
      if (result.ran) console.log('WA Gateway auto-reminder sweep:', result);
    } catch (err) { console.error('WA Gateway auto-reminder sweep gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });

  // WA Gateway auto-reconnect watchdog — tiap menit: bila sesi WAHA STOPPED/FAILED/macet STARTING
  // (WAHA restart, container update, crash), sesi dinyalakan ulang otomatis dengan backoff, lalu
  // antrean dilanjutkan. Tidak menyentuh sesi yang WORKING atau yang sengaja di-logout Admin.
  cron.schedule('* * * * *', async () => {
    try { await refreshBroadcastStatuses(); } catch (err) { console.error('WA broadcast status gagal:', err.message); }
    try { await ensureGatewayAlive(); } catch (err) { console.error('WA Gateway watchdog gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });

  cron.schedule('*/5 * * * *', async () => {
    if (!process.env.GENIEACS_NBI_URL) return;
    try { const result=await syncAcsDevices();if(result.status==='success')console.log('ACS sync:',result.devices,'ONT,',result.linked,'mapping baru'); }
    catch (err) { console.error('ACS sync gagal:',err.message); }
  }, { timezone: 'Asia/Jakarta' });

  // v1.28 — pengingat umur cash di tim: dicek tiap 30 menit, dikirim maksimal sekali per hari (>= 08:00 WIB).
  cron.schedule('*/30 * * * *', async () => {
    try { const result = await runCashAgingAlert(); if (result.ran && result.notified) console.log('Cash aging alert:', result); }
    catch (err) { console.error('Cash aging alert gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });

  cron.schedule('* * * * *', async () => {
    try {
      const result = await deliverMobilePushes();
      if (result.configured && (result.sent || result.failed)) console.log('INKAMNET GO push:', result);
    } catch (err) { console.error('INKAMNET GO push gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });

  cron.schedule('30 3 * * 0', async () => {
    try { const result = await backupAllRouters(['rsc', 'backup']); console.log('NMS backup mingguan:', result.filter(row => row.status === 'success').length, 'berhasil'); }
    catch (err) { console.error('NMS backup gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });

  // NMS telemetry and stock alerts are deliberately low-frequency. The public
  // monitor page remains responsive because it reads the persisted samples,
  // while router polling happens in one bounded Promise.all batch.
  cron.schedule('*/5 * * * *', async () => {
    try { const result = await captureAllNmsTelemetry(); console.log('NMS telemetry:', result.routers, 'router(s)'); }
    catch (err) { console.error('NMS telemetry gagal:', err.message); }
    try { await scanLowStock(); } catch (err) { console.error('Stock alert gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });

  // OLT reachability — pings management_ip of every registered OLT (reuses the same ICMP
  // mechanism as ONT ping in acsService.js). Status feeds the OLT KPI card on /noc and the
  // registry page at /olt. Runs alongside the telemetry cron above so both are fresh together.
  cron.schedule('*/5 * * * *', async () => {
    try { const result = await pingAllOlts(); if (result.checked) console.log('OLT ping:', result.online, 'online,', result.offline, 'offline dari', result.checked); }
    catch (err) { console.error('OLT ping gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });

  // Network Incident & Alert Engine — dijalankan setelah telemetry di atas supaya status
  // router/ONT/OLT yang dievaluasi sudah yang paling baru. Aman berjalan tiap 5 menit karena
  // evaluateNetworkIncidents() sendiri idempotent (dedup via tabel network_incidents) dan
  // tidak melakukan apa pun jika toggle WA/tiket di Settings > Tampilan & Aplikasi dimatikan.
  cron.schedule('*/5 * * * *', async () => {
    try {
      const result = await evaluateNetworkIncidents();
      if (result.opened || result.resolved || result.ticketsCreated) console.log('Network Alert Engine:', result);
    } catch (err) { console.error('Network Alert Engine gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });

  // WAHA (the WhatsApp HTTP API service) keeps the actual WhatsApp session alive in its own
  // process independent of this app, so on boot we just sync our in-memory status mirror with
  // whatever WAHA currently reports — no QR re-scan needed unless nothing was ever linked there.
  initGatewayOnBoot().catch(err => console.error('WA Gateway: gagal sinkronisasi awal saat startup:', err.message));

  // NMS v2 poller (telemetry, PPP active diff, secret mirror, FO-cut detection) + retensi event.
  nmsPoller.start();
  const nmsAutomation = require('./services/nms/automation');
  cron.schedule('* * * * *', async () => {
    try { const done = await nmsAutomation.runDue(); if (done.length) console.log('NMS jadwal:', done); }
    catch (err) { console.error('NMS jadwal gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });
  cron.schedule('*/5 * * * *', async () => {
    try { const r = await nmsAutomation.maybeRunDailyIsolation(); if (r.ran) console.log('Cron isolasi:', r); } catch (err) { console.error('Cron isolasi gagal:', err.message); }
    try { const r = await nmsAutomation.maybeAutoSync(); if (r.ran) console.log('NMS auto Smart Sync:', r); } catch (err) { console.error('NMS auto sync gagal:', err.message); }
    try { const r = await nmsAutomation.maybeSendSummary(); if (r.ran) console.log('NMS ringkasan pagi terkirim ke', r.sent, 'nomor'); } catch (err) { console.error('NMS ringkasan gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });
  cron.schedule('50 23 * * *', async () => {
    try { console.log('NMS snapshot PPP:', await nmsAutomation.takeSnapshots()); } catch (err) { console.error('NMS snapshot gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });
  cron.schedule('45 2 * * *', async () => {
    try { await purgeNmsHistory(); } catch (err) { console.error('NMS purge gagal:', err.message); }
  }, { timezone: 'Asia/Jakarta' });

  const port = Number(process.env.PORT || 3000);
  const server = app.listen(port, '0.0.0.0', () => console.log(`INKAMNET Billing berjalan di port ${port}`));
  waRealtime.attach(server, sessionMiddleware, loadPermissions);
}

bootstrap().catch(err => { console.error('Startup gagal:', err); process.exit(1); });

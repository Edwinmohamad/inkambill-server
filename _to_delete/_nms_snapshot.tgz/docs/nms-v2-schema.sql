-- =============================================================================
-- INKAMNET NMS v2 — DDL referensi (MariaDB 10.6+/11.x, MySQL 8 kompatibel)
-- Sumber kebenaran runtime: services/nms/schema.js (ensureNmsV2Schema, idempotent,
-- dijalankan otomatis saat startup). File ini untuk review / provisioning manual.
--
-- Catatan desain:
--  * PK BIGINT UNSIGNED (bukan UUID) agar konsisten dengan tabel existing
--    (customers, routers, sites, users) sehingga FK & JOIN lama tidak perlu migrasi.
--  * `customers` TIDAK dibuat ulang — tabel existing dipakai; status layanan
--    active/isolated/suspended diturunkan sebagai VIRTUAL column `service_status`.
--  * `audit_logs` existing diperluas: entity_type/entity_id = target_type/target_id,
--    + kolom `details` (JSON teks) & `site_id`.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ppp_secrets (
  id                     BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  site_id                BIGINT UNSIGNED NOT NULL,
  router_id              BIGINT UNSIGNED NOT NULL,
  ros_id                 VARCHAR(32)  NULL COMMENT 'RouterOS .id (mis. *1A)',
  username               VARCHAR(128) NOT NULL,
  password_enc           TEXT         NULL COMMENT 'AES-256-GCM, tidak pernah dikirim ke browser',
  profile                VARCHAR(64)  NULL,
  original_profile       VARCHAR(64)  NULL COMMENT 'paket asal sebelum isolir',
  service                VARCHAR(20)  NULL,
  local_address          VARCHAR(64)  NULL,
  remote_address         VARCHAR(64)  NULL,
  caller_id              VARCHAR(64)  NULL COMMENT 'MAC lock',
  comment                VARCHAR(255) NULL,
  disabled               TINYINT(1)   NOT NULL DEFAULT 0,
  is_isolated            TINYINT(1)   NOT NULL DEFAULT 0,
  is_exempt              TINYINT(1)   NOT NULL DEFAULT 0,
  exempt_type            VARCHAR(20)  NULL COMMENT 'admin | free',
  customer_id            BIGINT UNSIGNED NULL,
  match_method           ENUM('pppoe_username','customer_code','customer_name','manual') NULL,
  sync_status            ENUM('synced','unsynced') NOT NULL DEFAULT 'unsynced',
  is_online              TINYINT(1)   NOT NULL DEFAULT 0,
  active_address         VARCHAR(64)  NULL,
  active_caller_id       VARCHAR(64)  NULL,
  active_uptime          VARCHAR(40)  NULL,
  last_login_at          DATETIME NULL,
  last_logout_at         DATETIME NULL,
  last_seen_on_router_at DATETIME NULL,
  removed_on_router_at   DATETIME NULL,
  last_synced_at         DATETIME NULL,
  created_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_ppp_router_username (router_id, username),  -- username unik per router (RouterOS)
  UNIQUE KEY uq_ppp_customer (customer_id),                  -- 1 pelanggan = 1 secret
  INDEX idx_ppp_site_sync (site_id, sync_status),
  INDEX idx_ppp_online (site_id, is_online),
  INDEX idx_ppp_username (username),
  CONSTRAINT fk_ppp_router   FOREIGN KEY (router_id)   REFERENCES routers(id)   ON DELETE CASCADE,
  CONSTRAINT fk_ppp_site     FOREIGN KEY (site_id)     REFERENCES sites(id),
  CONSTRAINT fk_ppp_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
);

-- Live log, flapping & FO-cut detection. Retensi 30 hari (cron 02:45 WIB).
CREATE TABLE IF NOT EXISTS nms_ppp_events (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  router_id   BIGINT UNSIGNED NULL,
  site_id     BIGINT UNSIGNED NULL,
  username    VARCHAR(128) NULL,
  customer_id BIGINT UNSIGNED NULL,
  event_type  ENUM('login','logout','auth_failed','kick','isolate','unisolate','lock_mac') NOT NULL,
  address     VARCHAR(64)  NULL,
  caller_id   VARCHAR(64)  NULL,
  message     VARCHAR(255) NULL,
  source      ENUM('poll','webhook','log','action') NOT NULL DEFAULT 'poll',
  dedup_key   VARCHAR(191) NULL,
  occurred_at DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  UNIQUE KEY uq_nms_event_dedup (dedup_key),
  INDEX idx_nms_event_site_time (site_id, event_type, occurred_at),
  INDEX idx_nms_event_user_time (username, event_type, occurred_at),
  INDEX idx_nms_event_time (occurred_at)
);

-- Snapshot telemetry terakhir per router → fallback "SHOWING CACHED DATA".
CREATE TABLE IF NOT EXISTS nms_router_state (
  router_id      BIGINT UNSIGNED PRIMARY KEY,
  status         ENUM('online','offline','unknown') NOT NULL DEFAULT 'unknown',
  last_ok_at     DATETIME NULL,
  last_error     VARCHAR(500) NULL,
  telemetry_json LONGTEXT NULL,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Alert engine (mass disconnect / FO cut, router down).
CREATE TABLE IF NOT EXISTS nms_alerts (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  alert_type      ENUM('mass_disconnect','flapping','router_down') NOT NULL,
  severity        ENUM('critical','warning','info') NOT NULL DEFAULT 'warning',
  site_id         BIGINT UNSIGNED NULL,
  router_id       BIGINT UNSIGNED NULL,
  title           VARCHAR(255) NOT NULL,
  details         LONGTEXT NULL,
  dedup_key       VARCHAR(191) NOT NULL,   -- 1 alert terbuka per (tipe, site/router)
  opened_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolved_at     DATETIME NULL,
  acknowledged_by BIGINT UNSIGNED NULL,
  UNIQUE KEY uq_nms_alert_dedup (dedup_key),
  INDEX idx_nms_alert_open (resolved_at, alert_type)
);

-- Tabel existing yang disesuaikan
ALTER TABLE routers    ADD COLUMN IF NOT EXISTS wan_interface VARCHAR(64) NULL;
ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS details LONGTEXT NULL;   -- JSON
ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS site_id BIGINT UNSIGNED NULL;
CREATE INDEX IF NOT EXISTS idx_audit_target    ON audit_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_site_time ON audit_logs(site_id, created_at);
ALTER TABLE customers  ADD COLUMN IF NOT EXISTS service_status VARCHAR(12)
  GENERATED ALWAYS AS (CASE WHEN customer_status='suspended' THEN 'suspended'
                            WHEN network_status='isolated'   THEN 'isolated'
                            ELSE 'active' END) VIRTUAL;

-- Opsional (TIDAK dijalankan otomatis): hapus data modul Network Map lama bila sudah yakin.
-- DROP TABLE IF EXISTS network_map_links;
-- DROP TABLE IF EXISTS network_map_nodes;
